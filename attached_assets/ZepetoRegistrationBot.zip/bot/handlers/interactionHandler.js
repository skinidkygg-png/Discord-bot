const {
  ModalBuilder, TextInputBuilder, TextInputStyle,
  ActionRowBuilder, EmbedBuilder, ButtonBuilder, ButtonStyle
} = require('discord.js');
const fs = require('fs');
const path = './data/registered.json';
const { createRegistrasiEmbed, panduanPertama, panduanLanjutan } = require('../utils/embeds');

if (!fs.existsSync(path)) fs.writeFileSync(path, '{}');
const registered = require('../data/registered.json');

module.exports = {
  name: 'interactionCreate',
  async execute(interaction) {
    if (interaction.isButton() && interaction.customId === 'open_daftar_modal') {
      if (registered[interaction.user.id]) {
        return interaction.reply({ content: '⚠️ Kamu sudah pernah mendaftar.', ephemeral: true });
      }

      const modal = new ModalBuilder()
        .setCustomId('daftar_modal')
        .setTitle('Formulir Pendaftaran Zepeto');

      const fields = [
        new TextInputBuilder().setCustomId('username').setLabel('Username Zepeto').setStyle(TextInputStyle.Short).setRequired(true),
        new TextInputBuilder().setCustomId('umur').setLabel('Umur').setStyle(TextInputStyle.Short).setRequired(true),
        new TextInputBuilder().setCustomId('link').setLabel('Link Profil Zepeto').setStyle(TextInputStyle.Short).setRequired(true),
      ];

      modal.addComponents(...fields.map(f => new ActionRowBuilder().addComponents(f)));

      return interaction.showModal(modal);
    }

    if (interaction.isModalSubmit() && interaction.customId === 'daftar_modal') {
      const username = interaction.fields.getTextInputValue('username');
      const umur = interaction.fields.getTextInputValue('umur');
      const link = interaction.fields.getTextInputValue('link');

      const regData = require('../data/registered.json');
      if (regData[interaction.user.id]) {
        return interaction.reply({ content: '❌ Kamu sudah pernah mendaftar.', ephemeral: true });
      }

      regData[interaction.user.id] = { username, umur, link };
      fs.writeFileSync(path, JSON.stringify(regData, null, 2));

      const embed = createRegistrasiEmbed({
        username,
        umur,
        link,
        userTag: interaction.user.tag
      });

      await interaction.reply({
        content: '✅ Pendaftaran berhasil!',
        embeds: [embed],
        ephemeral: true
      });

      const staffRoleId = '1141778117325758645';
      const role = interaction.guild.roles.cache.get(staffRoleId);
      if (role) {
        role.members.forEach(member => {
          member.send({ embeds: [embed] }).catch(() => {});
        });
      }

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('mengerti_button')
          .setLabel('✅ Saya Mengerti')
          .setStyle(ButtonStyle.Success)
      );

      await interaction.followUp({
        embeds: [panduanPertama()],
        components: [row],
        ephemeral: true
      });
    }

    if (interaction.isButton() && interaction.customId === 'mengerti_button') {
      await interaction.reply({
        embeds: [panduanLanjutan()],
        ephemeral: true
      });
    }
  }
};