const { EmbedBuilder } = require('discord.js');

module.exports = {
  createRegistrasiEmbed({ username, umur, link, userTag }) {
    return new EmbedBuilder()
      .setTitle('📋 Pendaftaran Baru')
      .addFields(
        { name: '👤 Username Zepeto', value: username },
        { name: '🎂 Umur', value: umur },
        { name: '🔗 Link Profil', value: link }
      )
      .setColor('#6C63FF')
      .setFooter({ text: `Didaftarkan oleh ${userTag}` })
      .setTimestamp();
  },

  panduanPertama() {
    return new EmbedBuilder()
      .setTitle('📘 Panduan Awal')
      .setDescription('Terima kasih telah mendaftar!\n\n📍 Harap pastikan kamu aktif di server dan siap mengikuti bimbingan dari tim kami.\n\nKlik tombol di bawah untuk melanjutkan membaca panduan.')
      .setColor('#4FD1C5');
  },

  panduanLanjutan() {
    return new EmbedBuilder()
      .setTitle('📚 Panduan Lanjutan')
      .setDescription('✅ Kamu telah menyelesaikan tahap pendaftaran awal.\n\nSelanjutnya:\n- Tunggu DM dari staff\n- Jangan ganti username tanpa pemberitahuan\n- Patuhi aturan komunitas\n\n💬 Jika ada pertanyaan, silakan buka thread di server.')
      .setColor('#9F7AEA');
  }
};