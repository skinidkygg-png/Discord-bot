const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('daftar')
    .setDescription('Daftar menjadi anggota resmi Eastcostra Zepeto Squad'),

  async execute(interaction) {
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('open_daftar_modal')
        .setLabel('📝 Daftar Sekarang')
        .setStyle(ButtonStyle.Primary)
    );

    await interaction.reply({
      content: 'Klik tombol di bawah untuk mulai proses pendaftaran:',
      components: [row],
      ephemeral: true,
    });
  },
};